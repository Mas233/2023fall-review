/*
*********************************************************************************************************
*                                            EXAMPLE CODE
*
*               This file is provided as an example on how to use Micrium products.
*
*               Please feel free to use any application code labeled as 'EXAMPLE CODE' in
*               your application products.  Example code may be used as is, in whole or in
*               part, or may be used as a reference only. This file can be modified as
*               required to meet the end-product requirements.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*
*               You can find our product's user manual, API reference, release notes and
*               more information at https://doc.micrium.com.
*               You can contact us at www.micrium.com.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                              uC/OS-II
*                                            EXAMPLE CODE
*
* Filename : main.c
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/

#include  <cpu.h>
#include  <lib_mem.h>
#include  <os.h>

#include  "app_cfg.h"


/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/

static  OS_STK  StartupTaskStk[APP_CFG_STARTUP_TASK_STK_SIZE];
OS_STK        Task1Stk[APP_CFG_STARTUP_TASK_STK_SIZE];
OS_STK        Task2Stk[APP_CFG_STARTUP_TASK_STK_SIZE];
OS_STK        Task3Stk[APP_CFG_STARTUP_TASK_STK_SIZE];
INT32U		  task1Time[3];
INT32U		  task2Time[3];
INT32U		  task3Time[3];
INT32U		  startTime1 = 1;
INT32U		  startTime2 = 1;
INT32U		  startTime3 = 1;

/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*********************************************************************************************************
*/

static  void  StartupTask (void  *p_arg);
void  Task1(void *p_arg);
void  Task2(void *p_arg);
void  Task3(void *p_arg);
void  createTaskSet();


/*
*********************************************************************************************************
*                                                main()
*
* Description : This is the standard entry point for C code.  It is assumed that your code will call
*               main() once you have performed all necessary initialization.
*
* Arguments   : none
*
* Returns     : none
*
* Notes       : none
*********************************************************************************************************
*/

int  main (void)
{
#if OS_TASK_NAME_EN > 0u
    CPU_INT08U  os_err;
#endif

    OSInit();                                                   /* Initialize uC/OS-II                                  */

	createTaskSet();

#if OS_TASK_NAME_EN > 0u
    OSTaskNameSet(         APP_CFG_STARTUP_TASK_PRIO,
                  (INT8U *)"Startup Task",
                           &os_err);
#endif
	printf("Time\tevent\tfrom\tto\n");
    OSStart();                                                  /* Start multitasking (i.e. give control to uC/OS-II)   */

}


/*
*********************************************************************************************************
*                                            STARTUP TASK
*
* Description : This is an example of a startup task.  As mentioned in the book's text, you MUST
*               initialize the ticker only once multitasking has started.
*
* Arguments   : p_arg   is the argument passed to 'StartupTask()' by 'OSTaskCreate()'.
*
* Returns     : none
*
* Notes       : 1) The first line of code is used to prevent a compiler warning because 'p_arg' is not
*                  used.  The compiler should not generate any code for this statement.
*********************************************************************************************************
*/

static  void  StartupTask (void *p_arg)
{
   (void)p_arg;

    OS_TRACE_INIT();                                            /* Initialize the uC/OS-II Trace recorder               */

#if OS_CFG_STAT_TASK_EN > 0u
    OSStatTaskCPUUsageInit(&err);                               /* Compute CPU capacity with no task running            */
#endif

#ifdef CPU_CFG_INT_DIS_MEAS_EN
    CPU_IntDisMeasMaxCurReset();
#endif
    
    APP_TRACE_DBG(("uCOS-III is Running...\n\r"));

    while (DEF_TRUE) {                                          /* Task body, always written as an infinite loop.       */
        OSTimeDlyHMSM(0u, 0u, 1u, 0u);
		APP_TRACE_DBG(("Time: %d\n\r", OSTimeGet()));
    }
}

void createTaskSet() {
	INT32U c1 = 1, c2 = 1, c3 = 1;
	INT32U t1 = 2, t2 = 4, t3 = 6;
	INT32U startTime1 = 1;
	INT32U startTime2 = 1;
	INT32U startTime3 = 1;

	task1Time[0] = c1;
	task1Time[1] = startTime1;
	task1Time[2] = startTime1 + t1;

	task2Time[0] = c2;
	task2Time[1] = startTime2;
	task2Time[2] = startTime2 + t2;

	task3Time[0] = c3;
	task3Time[1] = startTime3;
	task3Time[2] = startTime3 + t3;

	OSTaskCreateExt((void(*)(void *))Task1,
		(void *)0,
		(OS_STK *)&Task1Stk[APP_CFG_STARTUP_TASK_STK_SIZE - 1u],
		(INT8U)1u,
		(INT16U)1u,
		(OS_STK *)&Task1Stk[0u],
		APP_CFG_STARTUP_TASK_STK_SIZE,
		(void *)task1Time,
		OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

	OSTaskCreateExt((void(*)(void *))Task2,
		(void *)0,
		(OS_STK *)&Task2Stk[APP_CFG_STARTUP_TASK_STK_SIZE - 1u],
		(INT8U)2u,
		(INT16U)2u,
		(OS_STK *)&Task2Stk[0u],
		APP_CFG_STARTUP_TASK_STK_SIZE,
		(void *)task2Time,
		OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

	OSTaskCreateExt((void(*)(void *))Task3,
		(void *)0,
		(OS_STK *)&Task3Stk[APP_CFG_STARTUP_TASK_STK_SIZE - 1u],
		(INT8U)3u,
		(INT16U)3u,
		(OS_STK *)&Task3Stk[0u],
		APP_CFG_STARTUP_TASK_STK_SIZE,
		(void *)task3Time,
		OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

}

void  Task1(void *p_arg)
{
	p_arg = p_arg;
#if OS_TASK_STAT_EN > 0
	OSStatInit();
#endif
	int toDelay;
	int c = task1Time[0];
	int T = task1Time[2] - task1Time[1];
	if (OSTimeGet() < startTime1) {
		OSTimeDly(startTime1 - OSTimeGet());
	}
	while (DEF_TRUE) {
		while (OSTCBCur->resTime > 0){}
		toDelay = OSTCBCur->endTime - OSTimeGet();
		if (toDelay < 0) {
			OSTCBCur->resTime = 0;
			OSTCBCur->startTime = OSTimeGet();
			OSTCBCur->endTime = OSTCBCur->startTime + T;
			OSTimeDly(0u);
		}
		else {
			OSTCBCur->resTime = 0;
			OSTCBCur->startTime = OSTCBCur->endTime;
			OSTCBCur->endTime = OSTCBCur->startTime + T;
			OSTimeDly(toDelay);
		}
	}
}

void  Task2(void *p_arg)
{
	p_arg = p_arg;
#if OS_TASK_STAT_EN > 0
	OSStatInit();
#endif
	int toDelay;
	int c = task2Time[0];
	int T = task2Time[2] - task2Time[1];
	if (OSTimeGet() < startTime2) {
		OSTimeDly(startTime2 - OSTimeGet());
	}
	while (DEF_TRUE) {
		while (OSTCBCur->resTime > 0){}
		toDelay = OSTCBCur->endTime - OSTimeGet();
		if (toDelay < 0) {
			OSTCBCur->resTime = c;
			OSTCBCur->startTime = OSTimeGet();
			OSTCBCur->endTime = OSTCBCur->startTime + T;
			OSTimeDly(0u);

		}
		else {
			OSTCBCur->resTime = c;
			OSTCBCur->startTime = OSTCBCur->endTime;
			OSTCBCur->endTime = OSTCBCur->startTime + T;
			OSTimeDly(toDelay);
		}
	}
}
void  Task3(void *p_arg) {
	p_arg = p_arg;
#if OS_TASK_STAT_EN > 0
	OSStatInit();
#endif
	int toDelay;
	int c = task3Time[0];
	int T = task3Time[2] - task3Time[1];
	if (OSTimeGet() < startTime3) {
		OSTimeDly(startTime3 - OSTimeGet());
	}
	while (DEF_TRUE) {
		while (OSTCBCur->resTime > 0){}
		toDelay = OSTCBCur->endTime - OSTimeGet();
		if (toDelay < 0) {
			OSTCBCur->resTime = c;
			OSTCBCur->startTime = OSTimeGet();
			OSTCBCur->endTime = OSTCBCur->startTime + T;
			OSTimeDly(0u);
		}
		else {
			OSTCBCur->resTime = c;
			OSTCBCur->startTime = OSTCBCur->endTime;
			OSTCBCur->endTime = OSTCBCur->startTime + T;
			OSTimeDly(toDelay);
		}
	}
}